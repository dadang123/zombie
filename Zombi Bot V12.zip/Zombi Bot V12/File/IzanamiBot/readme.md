# IzanamiXploiter V 2.5
# [UPDATE] 16 November 2019
# If u have problem in BOT
# Contact me ?
# Email : hiruka404@gmail.com
# Telegram : @hiruka404

Only work for python 2.7

Module :

-pip install request
-pip install requests
-pip install colorama
-pip install bs4

U can run multithread for fast exploit xD

edit file run.py and go to line 488

p = Pool(25) change value 25 


Thanks you~

